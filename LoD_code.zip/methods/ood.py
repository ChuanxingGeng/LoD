import os
import argparse
import datetime
import time
from copy import deepcopy

import pandas as pd
import numpy as np
import importlib
import torch
from torch.utils.data import DataLoader, ConcatDataset, Subset
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torchvision.transforms import transforms

from methods.train import train_ood, train_ood_2
from utils.utils import seed_torch, str2bool, get_default_hyperparameters
from utils.schedulers import get_scheduler
from models.model_utils import get_model

from methods.ood_loaders import get_ood_loaders
import torch.multiprocessing
from sklearn.metrics import roc_curve, roc_auc_score
from sklearn.mixture import GaussianMixture, BayesianGaussianMixture
from sklearn.cluster import KMeans
from methods.proportional_sampler import BatchSchedulerSampler
from models.wrn import WideResNet
from tqdm import tqdm
import torch.nn.functional as F

# torch.multiprocessing.set_sharing_strategy('file_system')

parser = argparse.ArgumentParser("OOD")

parser.add_argument('--dataset', type=str, default='cifar100', help="")
parser.add_argument('--image_size', type=int, default=32)
parser.add_argument('--in_nums', type=int, default=100)
parser.add_argument('--ood_start_idx', type=int, default=5e4)
parser.add_argument('--ood_name', type=str, default='lsun', help='test out')

parser.add_argument('--optim', type=str, default=None, help="Which optimizer to use {adam, sgd}")
parser.add_argument('--batch_size', type=int, default=128)
parser.add_argument('--train_batch_size', type=int, default=96)

parser.add_argument('--lr', type=float, default=0.01, help="learning rate for model")
parser.add_argument('--weight_decay', type=float, default=1e-4, help="LR regularisation on weights")
parser.add_argument('--max-epoch', type=int, default=100)
parser.add_argument('--scheduler', type=str, default='cosine_warm_restarts')
parser.add_argument('--temp', type=float, default=1.0, help="temp")
parser.add_argument('--num_restarts', type=int, default=2, help='How many restarts for cosine_warm_restarts schedule')

parser.add_argument('--loss', type=str, default='Softmax')
parser.add_argument('--label_smoothing', type=float, default=None, help="Smoothing constant for label smoothing.No smoothing if None or 0")
parser.add_argument('--beta', type=float, default=0.1, help="weight for entropy loss")
parser.add_argument('--model', type=str, default='wrn_40_2')
parser.add_argument('--feat_dim', type=int, default=128, help="Feature vector dim, only for classifier32 at the moment")

parser.add_argument('--transform', type=str, default='rand-augment-ood')
parser.add_argument('--rand_aug_m', type=int, default=6)
parser.add_argument('--rand_aug_n', type=int, default=1)

parser.add_argument('--num_workers', default=8, type=int)
parser.add_argument('--use_default_parameters', default=False, type=str2bool, help='Set to True to use optimized hyper-parameters from paper', metavar='BOOL')
parser.add_argument('--device', default='cuda:0', type=str, help='Which GPU to use')
parser.add_argument('--gpus', default=[0], type=int, nargs='+', help='device ids assignment (e.g 0 1 2 3)')
parser.add_argument('--gpu', type=str, default='0')
parser.add_argument('--seed', type=int, default=0)
parser.add_argument('--use-cpu', action='store_true')
parser.add_argument('--use_softmax_in_eval', default=False, type=str2bool, help='Do we use softmax or logits for evaluation', metavar='BOOL')
parser.add_argument('--ft_epochs', type=int, default=100)
parser.add_argument('--ft_weight', type=int, default=10)
parser.add_argument('--loss_add', type=int, default=1)
parser.add_argument('--ft_lr', type=float, default=0.001, help="learning rate for b_model")
parser.add_argument('--ft_score', type=str, default='mean_and_std')
parser.add_argument('--cluster_method', type=str, default='BGMM')
parser.add_argument('--flag_train', type=int, default=0)
parser.add_argument('--in_ratio', type=float, default=0.5, help="id split ratio")
parser.add_argument('--ood_ratio', type=float, default=0.7, help="ood split ratio")
parser.add_argument('--pi_ratio', type=float, default=0.1, help="ood batch ratio")
parser.add_argument('--num_ood', type=int, default=0, help='0 means all ood, n means n images')
parser.add_argument('--diff_aux_test', type=int, default=1, help='0 means aux(wild out) == test out, 1 means different')
parser.add_argument('--train_binary_classifier', type=int, default=0, help='')
parser.add_argument('--flag_computeX', type=int, default=1, help='')
parser.add_argument('--selected_nums', type=int, default=25000, help='selected nums of 300K images')


def get_optimizer(args, params_list):
    if args.optim is None:

        if options['dataset'] == 'tinyimagenet':
            optimizer = torch.optim.Adam(params_list, lr=args.lr)
        else:
            optimizer = torch.optim.SGD(params_list, lr=args.lr, momentum=0.9, weight_decay=args.weight_decay)

    elif args.optim == 'sgd':

        optimizer = torch.optim.SGD(params_list, lr=args.lr, momentum=0.9, weight_decay=args.weight_decay)

    elif args.optim == 'adam':

        optimizer = torch.optim.Adam(params_list, lr=args.lr)

    else:

        raise NotImplementedError

    return optimizer


def get_mean_lr(optimizer):
    return torch.mean(torch.Tensor([param_group['lr'] for param_group in optimizer.param_groups])).item()


# TODO: Args and options are largely duplicates: tidy up
def main_worker(options, args):
    if args.diff_aux_test == 0:
        loss_filename_npz = f'losseach_ood_{args.dataset}_{args.ood_name}_epoch{args.max_epoch}_in{args.in_ratio}ood{args.ood_ratio}pi{args.pi_ratio}.npz'
    else:
        loss_filename_npz = f'losseach_ood_{args.dataset}_{int(args.selected_nums)}_epoch{args.max_epoch}_in{args.in_ratio}ood{args.ood_ratio}pi{args.pi_ratio}.npz'
    print('Loss File Name：{}'.format(loss_filename_npz))
    torch.manual_seed(args.seed)
    os.environ['CUDA_VISIBLE_DEVICES'] = options['gpu']
    use_gpu = torch.cuda.is_available()
    if options['use_cpu']: use_gpu = False

    if use_gpu:
        print("Currently using GPU: {}".format(options['gpu']))
        cudnn.benchmark = True
        torch.cuda.manual_seed_all(options['seed'])
    else:
        print("Currently using CPU")

    print("Creating model: {}".format(options['model']))
    net = get_model(args)

    feat_dim = args.feat_dim

    # Loss
    options.update(
        {
            'feat_dim': feat_dim,
            'use_gpu': use_gpu
        }
    )

    Loss = importlib.import_module('methods.loss.' + options['loss'])
    criterion = getattr(Loss, options['loss'])(**options)

    if use_gpu:
        net = net.cuda()
        criterion = criterion.cuda()

    start_time = time.time()

    in_train_loader, wild_in_loader, wild_out_loader, in_train, in_test, out_test, combined_aux = get_ood_loaders(options, args)
    # _flag_train = False
    # if not os.path.exists(loss_filename_npz):
    # args.flag_train = 1
    if args.flag_train == 1:

        '''training '''
        start_epoch = 0
        in_features = net.fc.in_features
        out_features = net.fc.out_features
        net.fc = nn.Linear(in_features, out_features + 1, bias=False)
        net = net.cuda()
        print(f'out_layers: {out_features + 1}')

        osr_idx, osr_loss_each = [], []

        params_list = [{'params': net.parameters()},
                       {'params': criterion.parameters()}]

        # Get base network and criterion
        optimizer = get_optimizer(args=args, params_list=params_list)

        scheduler = get_scheduler(optimizer, args)

        for epoch in range(start_epoch, options['max_epoch']):
            print("==> Epoch {}/{}".format(epoch + 1, options['max_epoch']))
            args.cur_epoch = epoch + 1

            # _, _idx, _loss_each = train_ood(net, criterion, optimizer, concatloader, **options)
            _, _idx, _loss_each = train_ood_2(net, criterion, optimizer, in_train_loader, wild_in_loader, wild_out_loader, args, **options)

            osr_idx.extend(_idx)
            osr_loss_each.extend(_loss_each)

            if args.scheduler == 'multi_step' or args.scheduler == 'cosine':
                scheduler.step()
            else:
                scheduler.step(epoch=epoch)

            if (epoch + 1) % 10 == 0:
                data_idx = np.concatenate(osr_idx, 0)
                data_loss_each = np.concatenate(osr_loss_each, 0)
                # np.savez(f"tmp_losseach_ood_{args.dataset}_{args.ood_name}_epoch{args.cur_epoch}_in{args.in_ratio}ood{args.ood_ratio}pi{args.pi_ratio}.npz", data_idx=data_idx, data_loss_each=data_loss_each)
                find_ood(data_idx, data_loss_each, args)

        elapsed = round(time.time() - start_time)
        elapsed = str(datetime.timedelta(seconds=elapsed))

        data_idx = np.concatenate(osr_idx, 0)
        data_loss_each = np.concatenate(osr_loss_each, 0)

        '''save loss file'''
        # pd.concat([pd.DataFrame(data_idx), pd.DataFrame(data_loss_each)], axis=1).to_csv(loss_filename, header=False, index=False)
        np.savez(loss_filename_npz, data_idx=data_idx, data_loss_each=data_loss_each)
        print("Finished. Total elapsed time (h:m:s): {}".format(elapsed))
    else:
        print("Already exists.....loading.....")
        _data = np.load(loss_filename_npz)
        data_idx = _data['data_idx']
        data_loss_each = _data['data_loss_each']

    if args.train_binary_classifier == 1:
        find_ood(data_idx, data_loss_each, args)

    '''binary loader'''

    def test_ood_function(test_loader_in):
        index = 0
        with torch.no_grad():
            for in_set in test_loader_in:
                out, _ = binary_classifier.forward_my1(in_set[0].cuda())

                if index == 0:
                    logistic_all = logistic_regression(out).view(-1)
                else:
                    logistic_all = torch.cat([logistic_all, logistic_regression(out).view(-1)], -1)
                index += 1
        return logistic_all.cpu().detach().numpy()

    def test_ood_function_energy(test_loader_in):
        index = 0
        with torch.no_grad():
            for in_set in test_loader_in:
                out, out_logits1 = binary_classifier.forward_my1(in_set[0].cuda())

                if index == 0:
                    logistic_all = logistic_regression(out).view(-1)
                    logits_all = out_logits1
                else:
                    logistic_all = torch.cat([logistic_all, logistic_regression(out).view(-1)], -1)
                    logits_all = torch.cat([logits_all, out_logits1], 0)
                index += 1
        return logistic_all.cpu().detach().numpy(), logits_all.cpu().detach().numpy()

    '''不加wild_in'''
    pre_ood = Subset(combined_aux, args.tn_pre_idxs)

    # b_dataset = ConcatDataset([pre_ood, in_train])
    # b_loader = DataLoader(dataset=b_dataset,
    #                                    batch_size=options['batch_size']*2,
    #                                    sampler=BatchSchedulerSampler(b_dataset, train_batch_size=options['batch_size'], test_batch_size=options['batch_size']),
    #                                    shuffle=False,
    #                                    num_workers=args.num_workers,
    #                                    pin_memory=False)

    b_loader = DataLoader(in_train, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)
    pre_ood_loader = DataLoader(pre_ood, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)
    test_loader_in = DataLoader(in_test, batch_size=options['batch_size'], shuffle=False, num_workers=args.num_workers)
    test_loader_out = DataLoader(out_test, batch_size=options['batch_size'], shuffle=False, num_workers=args.num_workers)

    binary_classifier = WideResNet(40, args.in_nums, 2, dropRate=0.3).cuda()
    logistic_regression = torch.nn.Sequential(
        torch.nn.Linear(128, 1))

    if args.train_binary_classifier==1:
        logistic_regression = logistic_regression.cuda().train()
        binary_classifier.train()
        binary_cls_optimizer = torch.optim.SGD(list(binary_classifier.parameters()) + list(logistic_regression.parameters()),
                                               momentum=0.9,
                                               nesterov=True,
                                               lr=args.ft_lr, weight_decay=args.weight_decay)

        if args.in_nums == 10:
            binary_classifier.load_state_dict(torch.load(
                'pretrained/cifar10_wrn_pretrained_epoch_99.pt'))
        else:
            binary_classifier.load_state_dict(torch.load(
                'pretrained/cifar100_wrn_pretrained_epoch_99.pt'))

        # criterion = torch.nn.CrossEntropyLoss()

        binary_scheduler = torch.optim.lr_scheduler.LambdaLR(
            binary_cls_optimizer,
            lr_lambda=lambda step: cosine_annealing(
                step,
                args.ft_epochs * len(b_loader),
                1,  # since lr_lambda computes multiplicative factor
                1e-6 / args.ft_lr))




        for epoch in range(args.ft_epochs):
            ood_iter = iter(pre_ood_loader)
            for batch_idx, (data_id, labels_id, _) in enumerate(tqdm(b_loader)):
            # for batch_idx, (data, labels, _) in enumerate(tqdm(b_loader)):
                try:
                    data_ood = next(ood_iter)
                except StopIteration:
                    ood_iter = iter(pre_ood_loader)
                    data_ood = next(ood_iter)
                data = torch.cat([data_id, data_ood[0]], dim=0)
                labels = torch.cat([labels_id, data_ood[1]], dim=0)

                data, labels = data.to(torch.device('cuda')), labels.to(torch.device('cuda'))
                binary_cls_optimizer.zero_grad()
                out, out_logits = binary_classifier.forward_my1(data)
                loss = F.cross_entropy(out_logits[labels<args.in_nums], labels[labels<args.in_nums].cuda().long())

                output1 = logistic_regression(out)

                binary_labels = torch.ones(len(labels)).cuda()
                binary_labels[labels==args.in_nums] = 0

                energy_reg_loss = F.binary_cross_entropy_with_logits(output1.view(-1), binary_labels.float())
                if args.loss_add:
                    loss += args.ft_weight * energy_reg_loss
                else:
                    loss = args.ft_weight * energy_reg_loss

                loss.backward()
                binary_cls_optimizer.step()
                binary_scheduler.step()
            print('Epoch: ', epoch, 'Acc:', b_test(binary_classifier, test_loader_in))
            print('Loss: ', loss)

            if (epoch + 1) % 10 == 0:
                binary_classifier.eval()
                logistic_regression.eval()
                energy_id = test_ood_function(test_loader_in)
                energy_ood = test_ood_function(test_loader_out)

                from utils.metric_utils import get_measures, print_measures
                measures = get_measures(energy_id, energy_ood, plot=False)
                print_measures(measures[0], measures[1], measures[2])

                binary_classifier.train()
                logistic_regression.train()

        binary_classifier.eval()
        logistic_regression.eval()
        #save model
        try:
            if args.diff_aux_test==1:
                torch.save(binary_classifier, f'binary_classifier_{args.ft_lr}_{args.dataset}_{int(args.selected_nums)}_{args.ft_score}_{args.pi_ratio}_diff.pth')
                torch.save(logistic_regression, f'logistic_regression_{args.ft_lr}_{args.dataset}_{int(args.selected_nums)}_{args.ft_score}_{args.pi_ratio}_diff.pth')
            else:
                torch.save(binary_classifier, f'binary_classifier_{args.ft_lr}_{args.dataset}_{args.ood_name}_{args.ft_score}_{args.pi_ratio}.pth')
                torch.save(logistic_regression, f'logistic_regression_{args.ft_lr}_{args.dataset}_{args.ood_name}_{args.ft_score}_{args.pi_ratio}.pth')
        except:
            print('save model error!!!')
    else:
        print('loading existing binary classifier...')
        if args.diff_aux_test == 1:
            binary_classifier = torch.load(f'binary_classifier_{args.ft_lr}_{args.dataset}_{int(args.selected_nums)}_{args.ft_score}_{args.pi_ratio}_diff.pth')
            logistic_regression = torch.load(f'logistic_regression_{args.ft_lr}_{args.dataset}_{int(args.selected_nums)}_{args.ft_score}_{args.pi_ratio}_diff.pth')
        else:
            binary_classifier = torch.load(f'binary_classifier_{args.ft_lr}_{args.dataset}_{args.ood_name}_{args.ft_score}_{args.pi_ratio}.pth')
            logistic_regression = torch.load(f'logistic_regression_{args.ft_lr}_{args.dataset}_{args.ood_name}_{args.ft_score}_{args.pi_ratio}.pth')

    binary_classifier.eval()
    logistic_regression.eval()
    energy_id = test_ood_function(test_loader_in)
    energy_ood = test_ood_function(test_loader_out)

    from utils.metric_utils import get_measures, print_measures
    measures = get_measures(energy_id, energy_ood, plot=False)
    print('Acc:', b_test(binary_classifier, test_loader_in)*100)
    print_measures(measures[0], measures[1], measures[2])





def b_test(net, test_loader):
    net.eval()
    loss_avg = 0.0
    correct = 0

    with torch.no_grad():
        for data, target, _ in test_loader:
            data, target = data.cuda(), target.cuda().long()

            # forward
            output = net(data)

            loss = F.cross_entropy(output, target)

            # accuracy
            pred = output.data.max(1)[1]
            correct += pred.eq(target.data).sum().item()

            # test loss average
            loss_avg += float(loss.data)

    net.train()
    return correct / len(test_loader.dataset)


def cosine_annealing(step, total_steps, lr_max, lr_min):
    return lr_min + (lr_max - lr_min) * 0.5 * (
            1 + np.cos(step / total_steps * np.pi))


def find_ood(data_idx, data_loss_each, args):
    tp_idxs = np.arange(args.wild_in_nums, dtype=np.int32)
    tn_idxs = np.arange(args.wild_in_nums, args.wild_in_nums + args.wild_out_nums, dtype=np.int32)
    total_num = len(tp_idxs) + len(tn_idxs)
    print(f'total nums of id and ood: {total_num}')

    idxs = data_idx - args.ood_start_idx
    loss_dict = {idx: data_loss_each[np.where(idxs == idx)] for idx in range(total_num)}
    if args.diff_aux_test == 0:
        loss_filename_npz = f'lossX_ood_{args.dataset}_{args.ood_name}_epoch{args.max_epoch}_in{args.in_ratio}ood{args.ood_ratio}pi{args.pi_ratio}.npz'
    else:
        loss_filename_npz = f'lossX_ood_{args.dataset}_{int(args.selected_nums)}_epoch{args.max_epoch}_in{args.in_ratio}ood{args.ood_ratio}pi{args.pi_ratio}.npz'

    if args.flag_computeX == 1:
        if args.flag_train == 1:
            X = np.concatenate([np.array(v).squeeze()[:args.cur_epoch].reshape(1, -1) for v in loss_dict.values()])
        else:
            X = np.concatenate([np.array(v).squeeze()[:args.max_epoch].reshape(1, -1) for v in loss_dict.values()])

        np.savez(loss_filename_npz, data=X)
    else:
        X = np.load(loss_filename_npz)
        X = X['data']


    print(X.shape)
    X_mean = np.mean(X, axis=1)
    X_median = np.median(X, axis=1)
    X_std = np.std(X, axis=1)

    scores = {'mean': X_mean.squeeze(),
              'median': X_median.squeeze(),
              'std': X_std.squeeze(),
              'mean_and_std': np.concatenate([X_mean.squeeze().reshape(-1, 1), X_std.squeeze().reshape(-1, 1)], axis=1)
              }

    if args.ft_score == 'mean':
        fitting_score = scores['mean'].reshape(-1, 1)
    elif args.ft_score == 'std':
        fitting_score = scores['std'].reshape(-1, 1)
    elif args.ft_score == 'mean_and_std':
        fitting_score = scores['mean_and_std']
    elif args.ft_score == 'median':
        fitting_score = scores['median'].reshape(-1, 1)
    else:
        raise NotImplementedError

    if args.cluster_method == 'GMM':
        # GMM
        gm = GaussianMixture(n_components=2, max_iter=1000, tol=1e-6, init_params='kmeans', random_state=42).fit(fitting_score)
        gmcntr = gm.means_
        gmcluster_membership = gm.predict(fitting_score)
        gmproba = gm.predict_proba(fitting_score)

        print('=' * 10 + args.ft_score + 'GMM' + '=' * 10 + "\n")
        print_res(total_num, gmcntr, gmcluster_membership, gmproba, tp_idxs, tn_idxs, args)
    elif args.cluster_method == 'BGMM':
        # BGMM
        bgm = BayesianGaussianMixture(n_components=2, max_iter=1000, tol=1e-6, init_params='kmeans', random_state=42).fit(fitting_score)
        bgmcntr = bgm.means_
        bgmcluster_membership = bgm.predict(fitting_score)
        bgmproba = bgm.predict_proba(fitting_score)

        print('=' * 10 + args.ft_score + 'Bgmm' + '=' * 10)
        print_res(total_num, bgmcntr, bgmcluster_membership, bgmproba, tp_idxs, tn_idxs, args)
    elif args.cluster_method == 'kmeans':
        km = KMeans(n_clusters=2, random_state=42, max_iter=1000, tol=1e-6).fit(fitting_score)
        kmcntr = km.cluster_centers_
        kmcluster_membership = km.labels_
        print('=' * 10 + args.ft_score + 'KMeans' + '=' * 10)
        print_res_kmeans(total_num, kmcntr, kmcluster_membership, tp_idxs, tn_idxs, args)
    else:
        raise NotImplementedError

    print()



def print_res_kmeans(total_num, cntr, cluster_membership, tp_idxs, tn_idxs, args):
    known_label = np.argmax(cntr[:, 0])
    unknown_label = 1 - known_label
    print(known_label, unknown_label)
    tp_pre_idxs = np.where(cluster_membership == known_label)[0]
    tn_pre_idxs = np.where(cluster_membership == unknown_label)[0]
    args.tp_pre_idxs = tp_pre_idxs
    args.tn_pre_idxs = tn_pre_idxs
    print(len(tp_pre_idxs))
    print(len(tn_pre_idxs))
    correct_tp_num = np.intersect1d(tp_pre_idxs, tp_idxs)
    correct_tn_num = np.intersect1d(tn_pre_idxs, tn_idxs)

    try:
        recall_k = len(correct_tp_num) / len(tp_idxs)
        precision_k = len(correct_tp_num) / len(tp_pre_idxs)
    except ZeroDivisionError:
        recall_k = precision_k = 0

    try:
        recall_u = len(correct_tn_num) / len(tn_idxs)
        precision_u = len(correct_tn_num) / len(tn_pre_idxs)
    except ZeroDivisionError:
        recall_u = precision_u = 0

    print(f'known: recall:{recall_k}, precision:{precision_k}')
    print(f'unknown: recall:{recall_u}, precision:{precision_u}')



def print_res(total_num, cntr, cluster_membership, proba, tp_idxs, tn_idxs, args):
    known_label = np.argmax(cntr[:, 0])
    unknown_label = 1 - known_label
    print(known_label, unknown_label)

    tp_pre_idxs = np.where(cluster_membership == known_label)[0]
    tn_pre_idxs = np.where(cluster_membership == unknown_label)[0]
    args.tp_pre_idxs = tp_pre_idxs
    args.tn_pre_idxs = tn_pre_idxs
    print(len(tp_pre_idxs))
    print(len(tn_pre_idxs))
    correct_tp_num = np.intersect1d(tp_pre_idxs, tp_idxs)
    correct_tn_num = np.intersect1d(tn_pre_idxs, tn_idxs)

    try:
        recall_k = len(correct_tp_num) / len(tp_idxs)
        precision_k = len(correct_tp_num) / len(tp_pre_idxs)
    except ZeroDivisionError:
        recall_k = precision_k = 0

    try:
        recall_u = len(correct_tn_num) / len(tn_idxs)
        precision_u = len(correct_tn_num) / len(tn_pre_idxs)
    except ZeroDivisionError:
        recall_u = precision_u = 0

    print(f'known: recall:{recall_k}, precision:{precision_k}')
    print(f'unknown: recall:{recall_u}, precision:{precision_u}')




if __name__ == '__main__':
    args = parser.parse_args()

    if args.use_default_parameters:
        print('NOTE: Using default hyper-parameters...')
        args = get_default_hyperparameters(args)

    args.epochs = args.max_epoch
    img_size = args.image_size

    for i in range(1):
        seed_torch(args.seed)
        options = vars(args)
        options.update(
            {
                'item': i,
                'img_size': img_size,
            }
        )
        main_worker(options, args)
