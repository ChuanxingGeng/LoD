import os
from copy import deepcopy

import numpy as np
import torch.utils.data

from torch.utils.data import DataLoader, ConcatDataset
from torchvision.transforms import transforms

from methods.proportional_sampler import BatchSchedulerSampler, CombinedDataset, CustomDataset
from data.augmentations import get_transform
from config import ood_datasets_dir
import random
import argparse
import math
from tqdm import tqdm

from data.cifar import get_osr_cifar10, get_osr_cifar100
from data.tinyimagenet import get_osr_tiny
from data.open_set_splits.osr_splits import osr_splits

DATASETS_DIR = ood_datasets_dir





get_dataset_funcs = {
    'cifar10': get_osr_cifar10,
    'cifar_plus_10': get_osr_cifar100,
    'cifar_plus_50': get_osr_cifar100,
    'tinyimagenet': get_osr_tiny
}


def get_osr_datasets(exp_name='cifar10', transform='rand-augment', known_classes=(1,2), unknown_classes=(3), image_size=32, args=None):
    print('Loading datasets...')

    if isinstance(transform, tuple):
        train_transform, test_transform = transform
    else:
        train_transform, test_transform = get_transform(transform_type=transform, image_size=image_size, args=args)

    if exp_name in get_dataset_funcs.keys():
        datasets = get_dataset_funcs[exp_name](train_transform, test_transform, known_classes, unknown_classes, args)
    else:
        raise NotImplementedError

    return datasets



def get_osr_loaders(options, args):
    print(args)
    if args.dataset == 'cifar10':
        known_classes = osr_splits['cifar-10-10'][args.split_idx]
        unknown_classes = [x for x in range(10) if x not in known_classes]
    elif args.dataset == 'cifar_plus_10':
        known_classes = osr_splits['cifar-10-100'][args.split_idx]
        unknown_classes = osr_splits['cifar-10-100-10'][args.split_idx]
    elif args.dataset == 'cifar_plus_50':
        known_classes = osr_splits['cifar-10-100'][args.split_idx]
        unknown_classes = osr_splits['cifar-10-100-50'][args.split_idx]
    elif args.dataset == 'tinyimagenet':
        known_classes = osr_splits['tinyimagenet'][args.split_idx]
        unknown_classes = [x for x in range(200) if x not in known_classes]
    else:
        raise NotImplementedError

    args.in_nums = len(known_classes)

    args.wild_out_batch_size = math.ceil((args.batch_size - args.train_batch_size) * args.pi_ratio)
    args.wild_in_batch_size = args.batch_size - args.train_batch_size - args.wild_out_batch_size

    datasets = get_osr_datasets(exp_name=args.dataset, transform='rand-augment', known_classes=known_classes, unknown_classes=unknown_classes,
                                image_size=args.image_size, args=args)

    args.ood_start_idx = int(len(datasets['in_train']) / args.in_ratio)  # 5e4
    args.wild_out_nums = len(datasets['wild_out'])  # 5640
    args.in_test_nums = len(datasets['in_test'])  # 1e4
    args.wild_in_nums = len(datasets['wild_in'])  # 1e4
    args.ood_test_nums = len(datasets['ood_test'])
    print(f'ood_start_idx:{args.ood_start_idx}\n'
          f'in_test_nums:{args.in_test_nums}\n'
          f'wild_in_nums:{args.wild_in_nums}\n'
          f'wild_ood_nums:{args.wild_out_nums}\n'
          f'test_ood_nums:{args.ood_test_nums}\n'
          f'known_class_nums:{args.in_nums}\n')

    if args.transform == 'rand-augment-ood':
        if args.rand_aug_m is not None:
            if args.rand_aug_n is not None:
                datasets['in_train'].dataset.transform.transforms[0].m = args.rand_aug_m
                datasets['in_train'].dataset.transform.transforms[0].n = args.rand_aug_n

                datasets['wild_in'].dataset.transform.transforms[0].m = args.rand_aug_m
                datasets['wild_in'].dataset.transform.transforms[0].n = args.rand_aug_n

                datasets['wild_out'].dataset.transform.transforms[0].m = args.rand_aug_m
                datasets['wild_out'].dataset.transform.transforms[0].n = args.rand_aug_n

    in_train = CustomDataset(datasets['in_train'], start_idx=0, target_transform=None)
    wild_in = CustomDataset(datasets['wild_in'], start_idx=args.ood_start_idx, target_transform=lambda x: int(args.in_nums))
    wild_out = CustomDataset(datasets['wild_out'], start_idx=args.ood_start_idx + args.wild_in_nums, target_transform=lambda x: int(args.in_nums))



    in_train_loader = DataLoader(in_train, batch_size=args.train_batch_size, shuffle=True, num_workers=args.num_workers)
    wild_in_loader = DataLoader(wild_in, batch_size=args.wild_in_batch_size, shuffle=True, num_workers=args.num_workers)
    wild_out_loader = DataLoader(wild_out, batch_size=args.wild_out_batch_size, shuffle=True, num_workers=args.num_workers)


    _wild_in = deepcopy(datasets['wild_in'])
    _wild_out = deepcopy(datasets['wild_out'])
    _in_train = deepcopy(datasets['in_train'])

    mean = (0.4914, 0.4822, 0.4465)
    std = (0.2023, 0.1994, 0.2010)
    weak_transform = transforms.Compose([
        transforms.Resize((32,32)),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),

    ])
    _wild_in.dataset.transform = weak_transform
    _wild_out.dataset.transform = weak_transform
    _in_train.dataset.transform = weak_transform
    print(_in_train.dataset.transform)
    combined_aux = CombinedDataset(in_test=_wild_in, ood_dataset=_wild_out, start_idx=args.ood_start_idx)

    combined_aux.target_transform = lambda x: int(args.in_nums)
    return in_train_loader, wild_in_loader, wild_out_loader, _in_train, datasets['in_test'], datasets['ood_test'], combined_aux

