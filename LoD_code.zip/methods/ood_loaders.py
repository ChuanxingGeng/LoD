import os
from copy import deepcopy

import numpy as np
import torch.utils.data
from torchvision.datasets import ImageFolder, CIFAR10, CIFAR100
from torchvision.transforms import transforms

from data.svhn_loader import SVHN
from torch.utils.data import DataLoader, ConcatDataset
from methods.proportional_sampler import BatchSchedulerSampler, CombinedDataset, CustomDataset
from data.augmentations import get_transform
from config import ood_datasets_dir
import random
import argparse
import math
from tqdm import tqdm
from data.tinyimages_80mn_loader import RandomImages

DATASETS_DIR = ood_datasets_dir


class CustomCIFAR10(CIFAR10):

    def __init__(self, *args, **kwargs):
        super(CustomCIFAR10, self).__init__(*args, **kwargs)

        self.uq_idxs = np.array(range(len(self)))

    def __getitem__(self, item):
        img, label = super().__getitem__(item)
        uq_idx = self.uq_idxs[item]

        return img, label, uq_idx


class CustomCIFAR100(CIFAR100):

    def __init__(self, *args, **kwargs):
        super(CustomCIFAR100, self).__init__(*args, **kwargs)

        self.uq_idxs = np.array(range(len(self)))

    def __getitem__(self, item):
        img, label = super().__getitem__(item)
        uq_idx = self.uq_idxs[item]

        return img, label, uq_idx


class CustomImageFolder(ImageFolder):

    def __init__(self, *args, **kwargs):
        super(CustomImageFolder, self).__init__(*args, **kwargs)

        self.uq_idxs = np.array(range(len(self)))

    def __getitem__(self, item):
        img, label = super().__getitem__(item)
        uq_idx = self.uq_idxs[item]

        return img, label, uq_idx


def load_ood_dataset(args, transform):
    if args.ood_name == 'lsun':
        ood_set = ImageFolder(os.path.join(DATASETS_DIR, 'LSUN'), transform=transform, target_transform=lambda x: args.in_nums)
    elif args.ood_name == 'lsun_r':
        ood_set = ImageFolder(os.path.join(DATASETS_DIR, 'LSUN_resize'), transform=transform, target_transform=lambda x: args.in_nums)
    elif args.ood_name == 'isun':
        ood_set = ImageFolder(os.path.join(DATASETS_DIR, 'iSUN'), transform=transform, target_transform=lambda x: args.in_nums)
    elif args.ood_name == 'places':
        ood_set = ImageFolder(os.path.join(DATASETS_DIR, 'Places'), transform=transform, target_transform=lambda x: args.in_nums)  # 10000
    elif args.ood_name == 'textures':
        ood_set = ImageFolder(os.path.join(DATASETS_DIR, 'textures/images'), transform=transform, target_transform=lambda x: args.in_nums)
    elif args.ood_name == 'svhn':
        ood_set = SVHN(root=os.path.join(DATASETS_DIR, 'svhn'), split='test', transform=transform, target_transform=lambda x: args.in_nums)
    else:
        raise NotImplementedError
    return ood_set

    # ood_set = ImageFolder(os.path.join(DATASETS_DIR, 'places365'), transform=transform, target_transform=lambda x: args.in_nums)


def load_tinyimages_300k(args, transform, rng):
    _dir = os.path.join(DATASETS_DIR, '300K_random_images', '300K_random_images.npy')
    data = RandomImages(root=_dir, args=args, rng=rng, selected_nums=args.selected_nums, transform=transform)
    return data


def get_ood_datasets_cifar10(train_transform, test_transform, args):
    rng = np.random.default_rng(args.seed)

    '''ood'''
    if args.diff_aux_test == 1:  # wild_in != test_out
        ood_set_train = load_tinyimages_300k(args, train_transform, rng)  # wild_out
        ood_idx = np.array(range(len(ood_set_train)))
        rng.shuffle(ood_idx)

    else:
        ood_set_train = load_ood_dataset(args, train_transform)
        ood_idx = np.array(range(len(ood_set_train)))
        rng.shuffle(ood_idx)
        ood_train_len = int(args.ood_ratio * len(ood_set_train))  # 0.7*1w=7k
        if args.num_ood == 0:
            print('use all ood images.')
            wild_ood_idxs = ood_idx[:ood_train_len]
            ood_test_idxs = ood_idx[ood_train_len:]
        else:
            print('use {} ood images.'.format(args.num_ood))
            wild_ood_idxs = ood_idx[:args.num_ood]

    ood_set_test = load_ood_dataset(args, test_transform)

    '''ID'''
    in_train_ori = CustomCIFAR10(root=os.path.join(DATASETS_DIR, 'cifar10'), transform=train_transform, train=True, download=False)
    in_test = CustomCIFAR10(root=os.path.join(DATASETS_DIR, 'cifar10'), transform=test_transform, train=False, download=False)

    id_idx = np.array(range(len(in_train_ori)))
    rng.shuffle(id_idx)
    id_train_len = int(args.in_ratio * len(in_train_ori))  # 0.5*50000
    train_idxs = id_idx[:id_train_len]
    if args.num_ood == 0:
        print('use all wild_in images.')
        wild_in_idxs = id_idx[id_train_len:]
    else:
        tmp_used_num = int(args.num_ood * ((1 - args.pi_ratio) / args.pi_ratio))
        print('use {} wild_in images.'.format(tmp_used_num))  # num_ood*9
        if tmp_used_num > len(id_idx[id_train_len:]):
            print('wild_in images not enough, use all.')
            wild_in_idxs = id_idx[id_train_len:]
        else:
            wild_in_idxs = id_idx[id_train_len:id_train_len + tmp_used_num]

    if args.num_ood == 0:
        needed_wild_in_num = math.floor(len(wild_ood_idxs) / args.wild_out_batch_size * args.wild_in_batch_size)
        if needed_wild_in_num < len(wild_in_idxs):
            print('too many wild_in, drop some.')
            wild_in_idxs = wild_in_idxs[:needed_wild_in_num]

    args.in_train_idx = train_idxs
    args.wild_in_idx = wild_in_idxs
    print('train_num:{} \t wild_in_num:{} \t wild_out_num:{}'.format(len(train_idxs), len(wild_in_idxs), len(wild_ood_idxs)))

    ood_set_train = torch.utils.data.Subset(ood_set_train, wild_ood_idxs)

    in_train = torch.utils.data.Subset(in_train_ori, train_idxs)
    wild_in = torch.utils.data.Subset(in_train_ori, wild_in_idxs)

    all_datasets = {
        'in_train': in_train,
        'in_test': in_test,
        'wild_in': wild_in,
        'wild_out': ood_set_train,
        'ood_test': ood_set_test,
    }


    return all_datasets


def get_ood_datasets_cifar100(train_transform, test_transform, args):
    rng = np.random.default_rng(args.seed)

    '''ood'''
    if args.diff_aux_test == 1:  # wild_in != test_out
        ood_set_train = load_tinyimages_300k(args, train_transform, rng)# wild_out
        ood_idx = np.array(range(len(ood_set_train)))
        rng.shuffle(ood_idx)
        # ood_train_len = int(args.ood_ratio * len(ood_set_train))
        if args.num_ood == 0:
            print('use all ood images.')
            wild_ood_idxs = ood_idx
        else:
            print('use {} ood images.'.format(args.num_ood))
            wild_ood_idxs = ood_idx[:args.num_ood]
    else:# wild_in == test_out
        ood_set_train = load_ood_dataset(args, train_transform)
        ood_idx = np.array(range(len(ood_set_train)))
        rng.shuffle(ood_idx)
        ood_train_len = int(args.ood_ratio * len(ood_set_train))  # 0.7*1w=7k
        if args.num_ood == 0:
            print('use all ood images.')
            wild_ood_idxs = ood_idx[:ood_train_len]
            ood_test_idxs = ood_idx[ood_train_len:]
        else:
            print('use {} ood images.'.format(args.num_ood))
            wild_ood_idxs = ood_idx[:args.num_ood]

    ood_set_test = load_ood_dataset(args, test_transform)



    '''ID'''
    in_train_ori = CustomCIFAR100(root=os.path.join(DATASETS_DIR, 'cifar100'), transform=train_transform, train=True, download=False)
    in_test = CustomCIFAR100(root=os.path.join(DATASETS_DIR, 'cifar100'), transform=test_transform, train=False, download=False)

    id_idx = np.array(range(len(in_train_ori)))
    rng.shuffle(id_idx)
    id_train_len = int(args.in_ratio * len(in_train_ori))  # 0.5*50000
    train_idxs = id_idx[:id_train_len]
    if args.num_ood == 0:
        print('use all wild_in images.')
        wild_in_idxs = id_idx[id_train_len:]
    else:
        tmp_used_num = int(args.num_ood * ((1 - args.pi_ratio) / args.pi_ratio))
        print('use {} wild_in images.'.format(tmp_used_num))  # num_ood*9
        if tmp_used_num > len(id_idx[id_train_len:]):
            print('wild_in images not enough, use all.')
            wild_in_idxs = id_idx[id_train_len:]
        else:
            wild_in_idxs = id_idx[id_train_len:id_train_len + tmp_used_num]

    if args.num_ood == 0:
        needed_wild_in_num = math.floor(len(wild_ood_idxs) / args.wild_out_batch_size * args.wild_in_batch_size)
        if needed_wild_in_num < len(wild_in_idxs):
            print('too many wild_in, drop some.')
            wild_in_idxs = wild_in_idxs[:needed_wild_in_num]

    args.in_train_idx = train_idxs
    args.wild_in_idx = wild_in_idxs
    print('train_num:{} \t wild_in_num:{} \t wild_out_num:{}'.format(len(train_idxs), len(wild_in_idxs), len(wild_ood_idxs)))

    ood_set_train = torch.utils.data.Subset(ood_set_train, wild_ood_idxs)

    in_train = torch.utils.data.Subset(in_train_ori, train_idxs)
    wild_in = torch.utils.data.Subset(in_train_ori, wild_in_idxs)

    all_datasets = {
        'in_train': in_train,
        'in_test': in_test,
        'wild_in': wild_in,
        'wild_out': ood_set_train,
        'ood_test': ood_set_test,
    }

    return all_datasets




get_dataset_funcs = {
    'cifar10': get_ood_datasets_cifar10,
    'cifar100': get_ood_datasets_cifar100,
}


def get_ood_datasets(exp_name='cifar100', transform='rand-augment-ood', image_size=32, num_classes=10, args=None):
    print('Loading datasets...')

    if isinstance(transform, tuple):
        train_transform, test_transform = transform
    else:
        train_transform, test_transform = get_transform(transform_type=transform, image_size=image_size, args=args)

    if exp_name in get_dataset_funcs.keys():
        datasets = get_dataset_funcs[exp_name](train_transform, test_transform, args)
    else:
        raise NotImplementedError

    return datasets



def get_ood_loaders(options, args):
    print(f'in_dataset:{args.dataset}\n ood_dataset:{args.ood_name}\n img_size:{args.image_size}\n num_classes:{args.in_nums}\n')
    print(args)

    args.wild_out_batch_size = math.ceil((args.batch_size - args.train_batch_size) * args.pi_ratio)
    args.wild_in_batch_size = args.batch_size - args.train_batch_size - args.wild_out_batch_size

    datasets = get_ood_datasets(args.dataset, transform=args.transform, image_size=args.image_size, num_classes=args.in_nums, args=args)

    args.ood_start_idx = int(len(datasets['in_train']) / args.in_ratio)  # 5e4
    args.wild_out_nums = len(datasets['wild_out'])  # 5640
    args.in_test_nums = len(datasets['in_test'])  # 1e4
    args.wild_in_nums = len(datasets['wild_in'])  # 1e4
    args.ood_test_nums = len(datasets['ood_test'])
    print(f'ood_start_idx:{args.ood_start_idx}\n'
          f'in_test_nums:{args.in_test_nums}\n'
          f'wild_in_nums:{args.wild_in_nums}\n'
          f'ood_nums:{args.wild_out_nums}\n'
          f'test_ood_nums:{args.ood_test_nums}')

    if args.transform == 'rand-augment-ood':
        if args.rand_aug_m is not None:
            if args.rand_aug_n is not None:
                datasets['in_train'].dataset.transform.transforms[0].m = args.rand_aug_m
                datasets['in_train'].dataset.transform.transforms[0].n = args.rand_aug_n

                datasets['wild_in'].dataset.transform.transforms[0].m = args.rand_aug_m
                datasets['wild_in'].dataset.transform.transforms[0].n = args.rand_aug_n

                datasets['wild_out'].dataset.transform.transforms[0].m = args.rand_aug_m
                datasets['wild_out'].dataset.transform.transforms[0].n = args.rand_aug_n

    in_train = CustomDataset(datasets['in_train'], start_idx=0, target_transform=None)
    wild_in = CustomDataset(datasets['wild_in'], start_idx=args.ood_start_idx, target_transform=lambda x: int(args.in_nums))
    wild_out = CustomDataset(datasets['wild_out'], start_idx=args.ood_start_idx + args.wild_in_nums, target_transform=lambda x: int(args.in_nums))

    in_train_loader = DataLoader(in_train, batch_size=args.train_batch_size, shuffle=True, num_workers=args.num_workers)
    wild_in_loader = DataLoader(wild_in, batch_size=args.wild_in_batch_size, shuffle=True, num_workers=args.num_workers)
    wild_out_loader = DataLoader(wild_out, batch_size=args.wild_out_batch_size, shuffle=True, num_workers=args.num_workers)

    combined_aux = CombinedDataset(in_test=datasets['wild_in'], ood_dataset=datasets['wild_out'], start_idx=args.ood_start_idx)
    combined_aux.target_transform = lambda x: int(args.in_nums)

    return in_train_loader, wild_in_loader, wild_out_loader, datasets['in_train'], datasets['in_test'], datasets['ood_test'], combined_aux


