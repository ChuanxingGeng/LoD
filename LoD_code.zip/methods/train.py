import torch
from utils.utils import AverageMeter
import numpy as np
from tqdm import tqdm
import time

def train_osr(net, criterion, optimizer, trainloader, **options):
    net.train()
    losses = AverageMeter()
    torch.cuda.empty_cache()
    loss_all = 0
    _idx, _pred, _labels = [], [], []
    _idx_u, _pred_u, _labels_u = [], [], []
    _loss_each_u = []

    for batch_idx, (data, labels, idx) in enumerate(tqdm(trainloader)):

        if options['use_gpu']:
            data, labels = data.cuda(), labels.cuda()

        with torch.set_grad_enabled(True):
            optimizer.zero_grad()
            x, y = net(data, True)
            logits, loss, loss_each = criterion(x, y, labels)

            np_idx = idx.data.cpu().numpy()
            np_pred = logits.data.cpu().numpy()
            np_labels = labels.data.cpu().numpy()
            np_loss_each = loss_each.data.cpu().numpy()
            _idx.append(np_idx)
            _pred.append(np_pred)
            _labels.append(np_labels)

            pos = np.where(np_idx - 1e6 >= 0)[0]
            if len(pos):
                _idx_u.append(np_idx[pos])
                _pred_u.append(np_pred[pos])
                _labels_u.append(np_labels[pos])
                _loss_each_u.append(np_loss_each[pos])

            loss.backward()
            optimizer.step()

        losses.update(loss.item(), data.size(0))
        loss_all += losses.avg
    print("Batch {}/{}\t Loss {:.6f} ({:.6f})".format(batch_idx + 1, len(trainloader), losses.val, losses.avg))

    return loss_all, _idx_u, _loss_each_u


def train_ood(net, criterion, optimizer, trainloader, **options):
    net.train()
    losses = AverageMeter()
    torch.cuda.empty_cache()
    loss_all = 0
    _idx, _pred, _labels = [], [], []
    _idx_u, _pred_u, _labels_u = [], [], []
    _loss_each_u = []


    for batch_idx, (data, labels, idx) in enumerate(tqdm(trainloader)):
        if options['use_gpu']:
            data, labels = data.cuda(), labels.cuda()

        with torch.set_grad_enabled(True):
            optimizer.zero_grad()
            x, y = net(data, True)
            logits, loss, loss_each = criterion(x, y, labels)

            # save idx, logits, and its labels
            np_idx = idx.data.cpu().numpy()
            np_pred = logits.data.cpu().numpy()
            np_labels = labels.data.cpu().numpy()
            np_loss_each = loss_each.data.cpu().numpy()
            _idx.append(np_idx)
            _pred.append(np_pred)
            _labels.append(np_labels)

            pos = np.where(np_idx - options['ood_start_idx'] >= 0)[0]
            if len(pos):
                _idx_u.append(np_idx[pos])
                _pred_u.append(np_pred[pos])
                _labels_u.append(np_labels[pos])
                _loss_each_u.append(np_loss_each[pos])

            loss.backward()
            optimizer.step()

        losses.update(loss.item(), data.size(0))
        loss_all += losses.avg
    print("Batch {}/{}\t Loss {:.6f} ({:.6f})".format(batch_idx + 1, len(trainloader), losses.val, losses.avg))

    return loss_all, _idx_u, _loss_each_u


def train_ood_2(net, criterion, optimizer, in_train_loader, wild_in_loader, wild_out_loader, args, **options):
    net.train()
    losses = AverageMeter()
    torch.cuda.empty_cache()
    loss_all = 0
    _idx, _pred, _labels = [], [], []
    _idx_u, _pred_u, _labels_u = [], [], []
    _loss_each_u = []

    in_train_iter = iter(in_train_loader)
    wild_in_iter = iter(wild_in_loader)


    for batch_idx, (wild_out_data, wild_out_labels, wild_out_idx) in enumerate(tqdm(wild_out_loader)):
        try:
            wild_in_data, wild_in_labels, wild_in_idx = next(wild_in_iter)
        except StopIteration:
            wild_in_iter = iter(wild_in_loader)
            wild_in_data, wild_in_labels, wild_in_idx = next(wild_in_iter)

        try:
            in_train_data, in_train_labels, in_train_idx = next(in_train_iter)
        except StopIteration:
            in_train_iter = iter(in_train_loader)
            in_train_data, in_train_labels, in_train_idx = next(in_train_iter)

        if options['use_gpu']:
            wild_in_data, wild_in_labels = wild_in_data.cuda(), wild_in_labels.cuda()
            in_train_data, in_train_labels = in_train_data.cuda(), in_train_labels.cuda()
            wild_out_data, wild_out_labels = wild_out_data.cuda(), wild_out_labels.cuda()

        data = torch.cat((in_train_data, wild_in_data, wild_out_data), dim=0)
        labels = torch.cat((in_train_labels, wild_in_labels, wild_out_labels), dim=0)
        idx = torch.cat((in_train_idx, wild_in_idx, wild_out_idx), dim=0)

        with torch.set_grad_enabled(True):
            optimizer.zero_grad()
            x, y = net(data, True)
            logits, loss, loss_each = criterion(x, y, labels)

            # save idx, logits, and its labels
            np_idx = idx.data.cpu().numpy()
            np_pred = logits.data.cpu().numpy()
            np_labels = labels.data.cpu().numpy()
            np_loss_each = loss_each.data.cpu().numpy()
            _idx.append(np_idx)
            _pred.append(np_pred)
            _labels.append(np_labels)

            pos = np.where(np_idx - args.ood_start_idx >= 0)[0]
            if len(pos):
                _idx_u.append(np_idx[pos])
                _pred_u.append(np_pred[pos])
                _labels_u.append(np_labels[pos])
                _loss_each_u.append(np_loss_each[pos])


            loss.backward()
            optimizer.step()

        losses.update(loss.item(), data.size(0))
        loss_all += losses.avg
    print("Loss {:.6f} ({:.6f})".format(losses.val, losses.avg))

    return loss_all, _idx_u, _loss_each_u


