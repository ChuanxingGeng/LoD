import math
import torch
import random
from torch.utils.data.sampler import RandomSampler
import numpy as np
from torch.utils.data import Dataset, DataLoader


class BatchSchedulerSampler(torch.utils.data.sampler.Sampler):
    """
    iterate over tasks and provide a random batch per task in each mini-batch
    """

    def __init__(self, dataset, train_batch_size, test_batch_size):
        self.dataset = dataset
        self.train_batch_size = train_batch_size
        self.test_batch_size = test_batch_size
        self.number_of_datasets = len(dataset.datasets)  
        # self.largest_dataset_size = max([len(cur_dataset.samples) for cur_dataset in dataset.datasets])
        self.largest_dataset_size = max([len(cur_dataset) for cur_dataset in dataset.datasets])

        self.train_dataset_size = len(dataset.datasets[0])
        self.test_dataset_size = len(dataset.datasets[1])
        self.batch_size = train_batch_size + test_batch_size

    def __len__(self):
        
        return math.ceil(self.test_dataset_size / self.test_batch_size) * (self.train_batch_size + self.test_batch_size)
       
    def __iter__(self):
        samplers_list = []
        sampler_iterators = []
        for dataset_idx in range(self.number_of_datasets):
            cur_dataset = self.dataset.datasets[dataset_idx]
            sampler = RandomSampler(cur_dataset, replacement=False) 
            samplers_list.append(sampler)
            cur_sampler_iterator = sampler.__iter__()
            sampler_iterators.append(cur_sampler_iterator)

        push_index_val = [0] + self.dataset.cumulative_sizes[:-1]  
        samples_to_grab = [self.train_batch_size, self.test_batch_size] 


        epoch_samples = self.test_dataset_size


        final_samples_list = []  # this is a list of indexes from the combined dataset
        random.seed(0)

        for _ in range(0, epoch_samples, self.test_batch_size):
        # while len(final_samples_list) < epoch_samples:
            for i in range(self.number_of_datasets):
                cur_batch_sampler = sampler_iterators[i]
                cur_samples = []
                for _ in range(samples_to_grab[i]):
                    try:
                        cur_sample_org = cur_batch_sampler.__next__()
                        cur_sample = cur_sample_org + push_index_val[i]
                        cur_samples.append(cur_sample)
                    except StopIteration:  

                        if i == 1:
                            pass
                        else:
                            sampler_iterators[i] = samplers_list[i].__iter__()
                            cur_batch_sampler = sampler_iterators[i]
                            cur_sample_org = cur_batch_sampler.__next__()
                            cur_sample = cur_sample_org + push_index_val[i]
                            cur_samples.append(cur_sample)

                        

                random.shuffle(cur_samples)
                final_samples_list.extend(cur_samples)

        return iter(final_samples_list)


class CombinedDataset(Dataset):
    def __init__(self, in_test, ood_dataset, start_idx, transform=None, target_transform=None):
        self.in_test = in_test
        self.ood_dataset = ood_dataset
        self.start_idx = start_idx
        self.total_len = len(in_test) + len(ood_dataset)
        self.uq_idxs = np.arange(start_idx, start_idx + self.total_len)  
        self.target_transform = target_transform
        self.transform = transform

    def __len__(self):
        return self.total_len

    def __getitem__(self, idx):
        if idx < len(self.in_test):

            try:
                data, label, _ = self.in_test[idx]
                uq_idx = self.uq_idxs[idx]
            except ValueError:
                data, label = self.in_test[idx]
                uq_idx = self.uq_idxs[idx]
        else:

            try:
                data, label, _ = self.ood_dataset[idx - len(self.in_test)]
                uq_idx = self.uq_idxs[idx]
            except ValueError:
                data, label = self.ood_dataset[idx - len(self.in_test)]
                uq_idx = self.uq_idxs[idx]

        if self.transform is not None:
            data = self.transform(data)
        if self.target_transform is not None:
            label = self.target_transform(label)

        return data, label, uq_idx


class CustomDataset(Dataset):
    def __init__(self, dataset, start_idx, target_transform=None):
        self.dataset = dataset
        self.start_idx = start_idx
        self.total_len = len(dataset)
        self.uq_idxs = np.arange(start_idx, start_idx + self.total_len)
        self.target_transform = target_transform

    def __len__(self):
        return self.total_len

    def __getitem__(self, idx):
        try:
            data, label, _ = self.dataset[idx]
            uq_idx = self.uq_idxs[idx]
        except ValueError:
            data, label = self.dataset[idx]
            uq_idx = self.uq_idxs[idx]

        if self.target_transform is not None:
            label = self.target_transform(label)

        return data, label, uq_idx


