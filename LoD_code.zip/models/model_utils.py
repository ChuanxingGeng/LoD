
from models.wrn import WideResNet

import torch
import torch.nn as nn


def get_model(args):
    if args.model == 'wrn_40_2':
        model = WideResNet(40, args.in_nums, 2, 0.3)

    else:

        raise NotImplementedError

    return model
