#!/bin/bash
PYTHON='/path/to/python'
GPUID=0
AUG_M=6
AUG_N=1

LOSS='Softmax'
dataset='cifar100'
ood_name='textures'
batch_size=128
train_batch_size=96
image_size=32
lr=0.01
in_nums=100
FT_LR=0.001
FT_SCORE='mean'
CLUSTER_METHOD='kmeans'
IN_RATIO=0.5
OOD_RATIO=0.7
MAX_EPOCH=100
SELECTED_NUMS=25000
PI_RATIO=0.1
FLAG_2ND=1
FLAG_1ST=1
FLAG_X=1

while getopts "c:s:l:p:d:g:a:b:x:" opt; do
  case ${opt} in
    c )
      CLUSTER_METHOD=$OPTARG
      ;;
    s )
      FT_SCORE=$OPTARG
      ;;
    l )
      FT_LR=$OPTARG
      ;;
    p )
      PI_RATIO=$OPTARG
      ;;
    d )
      ood_name=$OPTARG
      ;;
    g )
      GPUID=$OPTARG
      ;;
    a )
      FLAG_1ST=$OPTARG
      ;;
    b )
      FLAG_2ND=$OPTARG
      ;;
    x )
      FLAG_X=$OPTARG
      ;;
    \? )
      echo "Usage: $0 [-c CLUSTER_METHOD] [-s FT_SCORE]"
      exit 1
      ;;
  esac
done

export CUDA_VISIBLE_DEVICES=$GPUID

echo batch_size:${batch_size} train_batch_size:${train_batch_size} in:${dataset} ood:${ood_name}
echo "ft_score:${FT_SCORE} cluster_method:${CLUSTER_METHOD} ft_lr:${FT_LR}"

${PYTHON} -m methods.ood --dataset=$dataset --loss=${LOSS} --use_default_parameters='False' --feat_dim=128 --weight_decay=5e-4 \
--num_workers=4 --gpu $GPUID --max-epoch=${MAX_EPOCH} --batch_size=${batch_size} --train_batch_size=${train_batch_size} --model='wrn_40_2' \
--transform='rand-augment-ood' --scheduler='cosine' --label_smoothing=0 --image_size=${image_size} --lr=${lr}  --train_binary_classifier=${FLAG_2ND}  \
--rand_aug_m=${AUG_M} --rand_aug_n=${AUG_N} --num_restarts=1 --seed=0 --in_nums=${in_nums} --ood_name=${ood_name} --ft_lr=${FT_LR} --ft_score=${FT_SCORE} \
--cluster_method=${CLUSTER_METHOD} --in_ratio=${IN_RATIO} --ood_ratio=${OOD_RATIO} --flag_train=${FLAG_1ST} --num_ood=0 --diff_aux_test=0 \
--pi_ratio=${PI_RATIO} --flag_computeX=${FLAG_X}
