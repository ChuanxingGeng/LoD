import numpy as np
import torch
from bisect import bisect_left
from torchvision.transforms import transforms
import time


class RandomImages(torch.utils.data.Dataset):

    def __init__(self, root, args, rng, selected_nums=10000, transform=None, exclude_cifar=False):

        # data_file = np.load('/nobackup-slow/dataset/my_xfdu/300K_random_images.npy')
        data_file = np.load(root)
        # rng = np.random.default_rng(seed=123)

        def load_image(idx):
            # data_file.seek(idx * 3072)
            # data = data_file.read(3072)
            data = data_file[idx]
            return np.asarray(data, dtype='uint8')#.reshape(32, 32, 3, order="F")

        self.load_image = load_image
        self.offset = 0     # offset index

        self.transform = transform
        self.args = args
        self.total_num = min(selected_nums, len(data_file))  # 使用的数据量，不超过数据文件的实际大小
        self.indices = rng.permutation(len(data_file))[:self.total_num]
        # self.exclude_cifar = exclude_cifar
        self.transform_to_pil = transforms.Compose([
            transforms.ToTensor(),
            transforms.ToPILImage()
        ])

        # if exclude_cifar:
        #     self.cifar_idxs = []
        #     with open('/nobackup-slow/dataset/80million/80mn_cifar_idxs.txt', 'r') as idxs:
        #         for idx in idxs:
        #             # indices in file take the 80mn database to start at 1, hence "- 1"
        #             self.cifar_idxs.append(int(idx) - 1)
        #
        #     # hash table option
        #     self.cifar_idxs = set(self.cifar_idxs)
        #     self.in_cifar = lambda x: x in self.cifar_idxs


    def __getitem__(self, index):
        index = self.indices[index]
        # index = (index + self.offset) % (self.total_num - 1)

        # if self.exclude_cifar:
        #     while self.in_cifar(index):
        #         index = np.random.randint(self.total_num)

        img = self.load_image(index)
        img = self.transform_to_pil(img)
        img = self.transform(img)

        return img, self.args.in_nums  # 0 is the class

    def __len__(self):
        return self.total_num