project_root_dir = '/LoD'
ood_datasets_dir = 'datasets'

cifar_10_root = 'datasets/cifar10'                                          # CIFAR10
cifar_100_root = 'datasets/cifar100'                                        # CIFAR100
tin_train_root_dir = 'datasets/tinyimagenet/tiny-imagenet-200/train'        # TinyImageNet Train
tin_val_root_dir = 'datasets/tinyimagenet/tiny-imagenet-200/val/images'     # TinyImageNet Val
tinyimages_300k_path = 'datasets/300K_random_images/300K_random_images.npy'