## Usage

## Requirements

To install requirements:

```setup
pip install -r requirements.txt
```

### Run

1. Download datasets. They are open access and can be easily obtained.
2. Modify the related dataset path in `config.py` 
3. Run the shell in `bash_scripts` folder.


